﻿namespace Koshelek.TestTask.Domain.Entities.Base.Interfaces
{
    public interface IBaseEntity
    {
        int Id { get; set; }
    }
}
