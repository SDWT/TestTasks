﻿using Microsoft.AspNetCore.SignalR;

namespace AspNetCorePostgreSQLDockerApp.Hubs
{
    public class MessagesHub : Hub
    {
    }
}
