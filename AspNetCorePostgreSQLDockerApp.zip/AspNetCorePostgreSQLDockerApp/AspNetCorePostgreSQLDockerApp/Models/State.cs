namespace AspNetCorePostgreSQLDockerApp.Models {
  public class State {
    public int Id { get; set; }
    public string Abbreviation { get; set; }
    public string Name { get; set; }
  }
}